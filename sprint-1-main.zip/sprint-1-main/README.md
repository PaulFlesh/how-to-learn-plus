Спринт 1 - "Статическая вёрстка".

Делал по брифам https://code.s3.yandex.net/web-plus/project-1/sprint-1-brief.pdf и https://code.s3.yandex.net/web-plus/project-1/sprint-2-brief.pdf

GitHub некорректно распознает пути к файлам по типу "/styles/table/__theme/table__theme_dark.css", поэтому оставил путь "/styles/table/theme/table__theme_dark.css"

В секции khan оставил изображение обложки размером 575x660, поскольку оно было неправильно растянуто в брифе (а именно 620x608 в книжной ориентации).
